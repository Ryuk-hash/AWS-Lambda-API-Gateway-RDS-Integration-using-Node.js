const mysql = require('mysql');

exports.handler = async (event) => {
  let student = event['params']['querystring']['student'];
  let batch = event['params']['querystring']['batch'];

  let response = {};

  if (!student || !batch) {
    response['status'] = 'Fail';
    response['statusCode'] = 400;
    response['status'] = 'Missing parameters!';

    return response;
  }

  let con = mysql.createConnection({
    host: 'database-1.csawygzvt1m9.us-east-2.rds.amazonaws.com',
    user: 'Ryuk-hash',
    password: 'yhnujm@123',
    database: 'database-1',
  });

  let sql = `INSERT INTO students (studentID, batchID) VALUES (${student}, ${batch})`;

  con.query(sql, function (err, result) {
    if (err) throw err;
    response = result;
  });

  return response;
};
